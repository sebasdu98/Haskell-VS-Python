mostrar_ubicacion:: Ord a=>[a]->Int-> a
mostrar_ubicacion l n = l!!n


