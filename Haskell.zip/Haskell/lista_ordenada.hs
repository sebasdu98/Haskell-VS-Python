lista_ordenada:: Ord a =>[a]->Bool
lista_ordenada []= True
lista_ordenada [_]= True
lista_ordenada (x:y:xs) = (x<=y) && lista_ordenada(y:xs)

