cuadrados::[Int]->[Int]
cuadrados []=[]
cuadrados l=[x*x|x<-l]



