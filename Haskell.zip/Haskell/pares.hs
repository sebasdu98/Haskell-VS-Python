contarpares::[Int]-> Int
contarpares[]=0
contarpares lista= length[x | x<- lista,mod x 2==0]


