
def buscar(n,vector):
    return vector[n]


    
print(buscar(2,[1,2,3,4,5,6,7]))


