def mayor(lista):

    mayor = 0
    maximo = len(lista) #Cantidad de numeros, puede variar
    for i in lista:
        num = i
        if num > mayor:
            mayor = num
    return mayor
print(mayor([1,2,3,4,5,6,9,150,20,151,153]))
