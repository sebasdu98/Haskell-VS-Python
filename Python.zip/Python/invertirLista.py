
def rever(vector):                  
    c = len(vector)
    c = c-1
    vecD =[]
    for i in range (0,len(vector)):
        a = vector[c]
        vecD.append(a)
        c=c-1
    return vecD
        

print (rever([1,2,3,4]))
