def cuadrados(lista):
    aux= []
    a=0
    for i in lista:
        aux.insert(a,i*i)
        a+=1
    return aux


print(cuadrados([1,2,3,4,5,6]))  
