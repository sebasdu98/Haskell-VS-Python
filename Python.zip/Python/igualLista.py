def comparar(lista1,lista2):
    if(lista1==lista2):
        return True
    else:
        return False


print(comparar(["Hola","mundo"],["Hola","mundo"]))
