def suma(lista):
    suma=0
    for i in lista:
        suma= suma+i
    return suma
print(suma([1,1,1,1,1]))
