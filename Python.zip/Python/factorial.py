def Fac(n):             
     a = 1
     for i in range(0,n):
         #print(a, n)
         a=a*n
         n=n-1
     return a
print(Fac(3))
